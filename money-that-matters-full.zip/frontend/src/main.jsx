import { useState } from 'react'
import { createRoot } from 'react-dom/client'
import './index.css'
import Header from './components/Header'
import Footer from './components/Footer'
import BottomNav from './components/BottomNav'
import { post } from './lib/api'
import Match from './pages/Match'
import News from './pages/News'
import Insiders from './pages/Insiders'
import Congress from './pages/Congress'
import Watchlist from './pages/Watchlist'

export default function App() {
  const [tab, setTab] = useState('match')
  const [refreshing, setRefreshing] = useState(false)
  const [watchlist, setWatchlistState] = useState(
    () => new Set(JSON.parse(localStorage.getItem('mtm_watchlist') || '[]')),
  )

  const setWatchlist = (ticker) =>
    setWatchlistState((current) => {
      const next = new Set(current)
      next.has(ticker) ? next.delete(ticker) : next.add(ticker)
      localStorage.setItem('mtm_watchlist', JSON.stringify([...next]))
      return next
    })

  async function refresh() {
    setRefreshing(true)
    try {
      await post('/refresh')
      location.reload()
    } finally {
      setRefreshing(false)
    }
  }

  return (
    <div className="min-h-screen bg-slate-50">
      <Header refreshing={refreshing} onRefresh={refresh} />
      {tab === 'match' && <Match watchlist={watchlist} setWatchlist={setWatchlist} />}
      {tab === 'news' && <News />}
      {tab === 'insiders' && <Insiders />}
      {tab === 'congress' && <Congress />}
      {tab === 'egypt' && <News egypt />}
      {tab === 'watchlist' && (
        <Watchlist watchlist={watchlist} setWatchlist={setWatchlist} />
      )}
      <Footer />
      <BottomNav tab={tab} setTab={setTab} />
    </div>
  )
}

createRoot(document.getElementById('root')).render(<App />)
